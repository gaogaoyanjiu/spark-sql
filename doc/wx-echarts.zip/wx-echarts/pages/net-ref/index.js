import * as echarts from '../../ec-canvas/echarts';

const app = getApp();

function initChart(canvas, width, height) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height
  });
  canvas.setChart(chart);

 var option = {
    title: {
      text: '网站访问来源',
      subtext: '总访问量 1588880000 次',
      x: 'center'
    },
    tooltip: {
      trigger: 'item',
      formatter: "{c}({d}%)"
    },
    legend: {
      orient: 'vertical',
      x: 'left',
      top: '60',
      // left: '10',
      data: ['百度','神马引擎','谷歌','360','搜狗','直接访问']
    },
    series: [
      {
        top: '60',
        // left: '-45',
        name: '访问来源',
        type: 'pie',
        radius: ['0%', '40%'],
        avoidLabelOverlap: true,
        label: {
          normal: {
            show: true,
            position: 'insideRight'
          },
          emphasis: {
            show: true,
            textStyle: {
              fontSize: '14',
              fontWeight: 'bold'
            }
          }
        },
        labelLine: {
          normal: {
            show: true
          }
        },
        data: [
          { value: 8096, name: '百度' },
          { value: 3668, name: '神马引擎' },
          { value: 2605, name: '谷歌' },
          { value: 3830, name: '360' },
          { value: 6090, name: '搜狗' },
          { value: 66868, name: '直接访问' }
        ],

        itemStyle: {
          emphasis: {
            shadowBlur: 3,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };


  // var option = {
  //   title: {
  //     text: '城市排名Top5',
  //     subtext: '总访问量 80000 次',
  //     x: 'center'
  //   },
  //   tooltip: {
  //     trigger: 'item',
  //     formatter: "{a} {b}: {c} ({d}%)"
  //   },
  //   legend: {
  //     orient: 'vertical',
  //     x: 'left',
  //     top: '45',
  //     left: '25',
  //     data: ['北京', '上海', '广州', '深圳', '重庆']
  //   },
  //   series: [
  //     {
  //       top: '60',
  //       name: '访问来源',
  //       type: 'pie',
  //       radius: ['25%', '40%'],
  //       avoidLabelOverlap: false,
  //       label: {
  //         normal: {
  //           show: true,
  //           // position: 'center'
  //         },
  //         emphasis: {
  //           show: false,
  //           textStyle: {
  //             fontSize: '30',
  //             fontWeight: 'bold'
  //           }
  //         }
  //       },
  //       labelLine: {
  //         normal: {
  //           show: true
  //         }
  //       },
  //       data: [
  //         { value: 896, name: '重庆' },
  //         { value: 368, name: '深圳' },
  //         { value: 1605, name: '广州' },
  //         { value: 2830, name: '上海' },
  //         { value: 8090, name: '北京' }
  //       ],

  //       itemStyle: {
  //         emphasis: {
  //           shadowBlur: 10,
  //           shadowOffsetX: 0,
  //           shadowColor: 'rgba(0, 0, 0, 0.5)'
  //         }
  //       }
  //     }
  //   ]
  // };

  chart.setOption(option);
  return chart;
}

Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/index/index',
      success: function () { },
      fail: function () { }
    }
  },
  data: {
    ec: {
      onInit: initChart
    }
  },

  onReady() {
    wx.clearStorageSync();
    setTimeout(function () {
      // 获取 chart 实例的方式
      // console.log(chart)
    }, 2000);
  }
});
