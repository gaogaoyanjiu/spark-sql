import * as echarts from '../../ec-canvas/echarts';

let chart = null;

function initChart(canvas, width, height) {
  chart = echarts.init(canvas, null, {
    width: width,
    height: height
  });
  canvas.setChart(chart);

//  var option = {

//    title: {
//      text: '热销品排名Top5',
//      subtext: '总访问量 326900 次',
//      x: 'center'
//    },
//     color: ['#000fff'],
//     tooltip: {
//       trigger: 'axis',
//       axisPointer: {            // 坐标轴指示器，坐标轴触发有效
//         type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
//       }
//     },
//     grid: {
//        left: '3%',
//       right: '4%',
//       bottom: '3%',
//       containLabel: true
//     },
//     xAxis: [
//       {
//         type: 'category',
//         data: ['大数据', '机器学习','虚拟化技术','云计算','图计算'],
//         axisTick: {
//           alignWithLabel: true
//         }
//       }
//     ],
//     yAxis: [
//       {
//         type: 'value'
//       }
//     ],
//     series: [
//       {
//         name: '访问量',
//         type: 'bar',
//         barWidth: '60%',
//         data: [12400, 9800,3500, 800,500]
//       }
//     ]
//   };

// var  option = {
//    title: {
//      text: '热销品排名Top5',
//      subtext: '总访问量 326900 次',
//      x: 'center'
//    },
//     xAxis: {
//       type: 'category',
//       data: ['大数据', '机器学习', '虚拟化技术', '云计算', '图计算'],
//     },
//     yAxis: {
//       type: 'value'
//     },
//     series: [{
//       data: [120, 200, 150, 80, 70],
//       type: 'bar'
//     }]
//   };

  var option = {
    title: {
      text: '热销品排名Top5',
      subtext: '总访问量 56000 次',
      x: 'center'
    },
    tooltip: {
      trigger: 'item',
      formatter: "{c}({d}%)"
    },
    legend: {
      orient: 'vertical',
      x: 'left',
      top: '60',
      left: '10',
      data: ['大数据', '机器学习', '虚拟化技术', '云计算', '图计算']
    },
    series: [
      {
        top: '100',
        name: '热销商品',
        type: 'pie',
        radius: ['0%', '30%'],
        avoidLabelOverlap: true,
        label: {
          normal: {
            show: true,
            position: 'insideLeft'
          },
          emphasis: {
            show: true,
            textStyle: {
              fontSize: '14',
              fontWeight: 'bold'
            }
          }
        },
        labelLine: {
          normal: {
            show: true
          }
        },
        data: [
          { value: 1096, name: '图计算' },
          { value: 668, name: '云计算' },
          { value: 1005, name: '虚拟化技术' },
          { value: 1330, name: '机器学习' },
          { value: 10360, name: '大数据' }
        ],

        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };


  chart.setOption(option);
  return chart;
}

Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/index/index',
      success: function () { },
      fail: function () { }
    }
  },
  data: {
    ec: {
      onInit: initChart
    }
  },

  onReady() {
    wx.clearStorageSync();
    setTimeout(function () {
      // 获取 chart 实例的方式
      console.log(chart)
    }, 2000);
  }
});
