import * as echarts from '../../ec-canvas/echarts';

const app = getApp();

function initChart(canvas, width, height) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height
  });
  canvas.setChart(chart);

  // var option = {
  //   backgroundColor: "#ffffff",
  //   //color: ["#37A2DA", "#32C5E9", "#67E0E3", "#91F2DE", "#FFDB5C", "#FF9F7F"],
  //   series: [{
  //     label: {
  //       normal: {
  //         fontSize: 14
  //       }
  //     },
  //     type: 'pie',
  //     center: ['50%', '50%'],
  //     radius: [0, '50%'],
  //     data: [{
  //       value: 55,
  //       name: 'PC'
  //     }, {
  //       value: 20,
  //       name: '微信'
  //     }, {
  //       value: 10,
  //       name: '平板电脑'
  //     }, {
  //       value: 20,
  //       name: '火狐'
  //     }, {
  //       value: 38,
  //       name: '百度'
  //     }, {
  //       value: 38,
  //       name: '谷歌'
  //     }
  //     ],
  //     itemStyle: {
  //       emphasis: {
  //         shadowBlur: 10,
  //         shadowOffsetX: 0,
  //         shadowColor: 'rgba(0, 2, 2, 0.3)'
  //       }
  //     }
  //   }]
  // };


  var option = {
    title: {
      text: '城市排名Top5',
      subtext: '总访问量 9000 次',
      x: 'center'
    },
    tooltip: {
      trigger: 'item',
      formatter: "{a} <br/>{b}: {c} ({d}%)"
    },
    legend: {
      orient: 'vertical',
      x: 'left',
      top: '40',
      left: '10',
      data: ['北京', '上海', '广州', '深圳', '重庆']
    },
    series: [
      {
        top: '60',
        name: '城市排名Top5',
        type: 'pie',
        radius: ['25%', '40%'],
        avoidLabelOverlap: false,
        label: {
          normal: {
            show: true,
            // position: 'center'
          },
          emphasis: {
            show: false,
            textStyle: {
              fontSize: '30',
              fontWeight: 'bold'
            }
          }
        },
        labelLine: {
          normal: {
            show: true
          }
        },
        data: [
          { value: 368, name: '重庆' },
          { value: 505, name: '深圳' },
          { value: 630, name: '广州' },
          { value: 990, name: '上海' },
          { value: 8868, name: '北京' }
        ],

        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };

  chart.setOption(option);
  return chart;
}

Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/index/index',
      success: function () { },
      fail: function () { }
    }
  },
  data: {
    ec: {
    }
  },

  onReady() {
    wx.clearStorageSync();
  },

  echartInit(e) {
    initChart(e.detail.canvas, e.detail.width, e.detail.height);
  }
});
