const app = getApp();

Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/index/index',
      success: function () {},
      fail: function () {}
    }
  },
  data: {
    charts: [
       {
        id: 'net-ref',
        name: '网站访问来源'
      }, {
        id: 'net-type',
        name: '访问来源类型'
      },{
        id: 'use-console',
        name: '用户终端访问量'
      }, {
        id: 'city-top5',
        name: '城市排名Top5'
      }, {
        id: 'u-new-old',
        name: '新/老用户访问量'
      },
      
      {
        id: 'net-operator',
      name: '网站运营商统计'
      }, {
        id: 'prod-top5',
        name: '热销品排名Top5'
      }, {
        id: 'gauge',
        name: '用户留存率'
      }, {
        id: 'line',
        name: '用户男/女比例'
      }
      
      ]
  },

  onReady() {
  },

  open: function (e) {
    wx.clearStorageSync();
    wx.navigateTo({
      url: '../' + e.target.dataset.chart.id + '/index'
    });
  }
});
