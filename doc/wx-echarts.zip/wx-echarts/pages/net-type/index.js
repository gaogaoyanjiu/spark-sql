import * as echarts from '../../ec-canvas/echarts';

const app = getApp();

function initChart(canvas, width, height) {
  const chart = echarts.init(canvas, null, {
    width: width,
    height: height
  });
  canvas.setChart(chart);

 var option = {
    title: {
      text: '网站访问类型',
      subtext: '总访问量 156000 次',
      x: 'center'
    },
    tooltip: {
      trigger: 'item',
      formatter: "{c}({d}%)"
    },
    legend: {
      orient: 'vertical',
      x: 'left',
      top: '60',
      left: '10',
      data: ['搜索引擎','外部链接','直接访问']
    },
    series: [
      {
        top: '60',
        name: '访问类型',
        type: 'pie',
        radius: ['0%', '40%'],
        avoidLabelOverlap: true,
        label: {
          normal: {
            show: true,
            position: 'insideRight'
          },
          emphasis: {
            show: true,
            textStyle: {
              fontSize: '14',
              fontWeight: 'bold'
            }
          }
        },
        labelLine: {
          normal: {
            show: true
          }
        },
        data: [
          { value: 1090, name: '搜索引擎' },
          { value: 830, name: '外部链接' },
          { value: 6868, name: '直接访问' }
        ],

        itemStyle: {
          emphasis: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };


  chart.setOption(option);
  return chart;
}

Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/index/index',
      success: function () { },
      fail: function () { }
    }
  },
  data: {
    ec: {
      onInit: initChart
    }
  },

  onReady() {
    wx.clearStorageSync();
    setTimeout(function () {
      // 获取 chart 实例的方式
      // console.log(chart)
    }, 2000);
  }
});
