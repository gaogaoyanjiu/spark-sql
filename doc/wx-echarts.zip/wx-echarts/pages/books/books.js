// 0. 在调用云开发各 API 前，需先调用初始化方法 init 一次（全局只需一次）
wx.cloud.init({
  env: 'feimaomiaomiaomiao-de26b8'
})
Page({
  data: { // 参与页面渲染的数据
    books: []
  },
  onLoad: function () {
    var me=this;
    // 1. 获取数据库引用
    const db = wx.cloud.database()
    // 2. 构造查询语句
    // collection 方法获取一个集合的引用
    // where 方法传入一个对象，数据库返回集合中字段等于指定值的 JSON 文档。API 也支持高级的查询条件（比如大于、小于、in 等），具体见文档查看支持列表
    // get 方法会触发网络请求，往数据库取数据
    db.collection('sparkSQL').where({
      //  publishInfo: {
      //    country: 'United States',
      //    year: 1951
      //  }
    }).get({
      success: function (res) {
        // 输出 [{ "title": "The Catcher in the Rye", ... }]
        console.log(res)
        me.setData({
          books: res
        })
      }
    })
  }
});
